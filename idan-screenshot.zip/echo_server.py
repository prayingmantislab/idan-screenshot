"""שרת הד: מחזיר ללקוח בדיוק את מה שהוא שלח."""
import socket

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind(("0.0.0.0", 8820))
server_socket.listen()
print("מחכה ללקוח...")

client_socket, address = server_socket.accept()
print("התחבר:", address)

while True:
    data = client_socket.recv(1024)      # מקבל עד 1024 בתים
    if not data:                         # הלקוח סגר את החיבור
        break
    print("קיבלתי:", data.decode())
    client_socket.send(data)             # מחזיר אותו הדבר ("הד")

client_socket.close()
server_socket.close()
