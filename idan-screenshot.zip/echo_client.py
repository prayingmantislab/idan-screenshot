"""לקוח הד: python3 echo_client.py [כתובת-שרת]"""
import socket
import sys

IP = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1"

my_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
my_socket.connect((IP, 8820))

while True:
    text = input("כתוב משהו (או exit): ")
    if text == "exit":
        break
    my_socket.send(text.encode())
    answer = my_socket.recv(1024)
    print("השרת ענה:", answer.decode())

my_socket.close()
